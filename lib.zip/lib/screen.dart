import 'package:flutter/material.dart';
import 'package:latihan_3/database/dbHelper.dart';
import 'database/myProvider.dart';
import 'package:latihan_3/model/ShoppingList.dart';
import 'package:provider/provider.dart';

class ScreenPertemuan3 extends StatefulWidget {
  const ScreenPertemuan3({Key? key}) : super(key: key);

  @override
  State<ScreenPertemuan3> createState() => _ScreenPertemuan3State();
}

class _ScreenPertemuan3State extends State<ScreenPertemuan3> {
  DBHelper _dbHelper = DBHelper();

  @override
  Widget build(BuildContext context) {
    var tmp = Provider.of<ListProductProvider>(context, listen: true);
    _dbHelper.getMyShoppingList().then((value) => tmp.setShoppingList = value);

    tmp.loadData();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Shopping List'),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(
                builder: (context) {
                  return const ScreenHistoryPertemuan3();
                },
              ));
            },
            icon: const Icon(Icons.history),
          ),
          IconButton(
            onPressed: () {
              _dbHelper.deleteAllShoppingList();
              tmp.deleteAll();
            },
            icon: const Icon(Icons.delete),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: tmp.shoppingList != [] ? tmp.shoppingList.length : 0,
        itemBuilder: (context, index) {
          return Dismissible(
              key: Key(tmp.shoppingList[index].name),
              onDismissed: (direction) {
                String tmpName = tmp.shoppingList[index].name;
                int tmpId = tmp.shoppingList[index].id;
                setState(() {
                  tmp.deleteById(tmp.shoppingList[index]);
                });
                _dbHelper.deleteShoppingList(tmpId);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text("$tmpName deleted"),
                  ),
                );
              },
              child: ListTile(
                title: Text(tmp.shoppingList[index].name),
                leading: CircleAvatar(
                  child: Text("${tmp.shoppingList[index].sum}"),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return ItemScreen(tmp.shoppingList[index]);
                  }));
                },
                trailing: IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (context) {
                        return ShoppingListDialog(_dbHelper).buildDialog(
                            context, tmp.shoppingList[index], false);
                      },
                    );
                    _dbHelper
                        .getMyShoppingList()
                        .then((value) => tmp.setShoppingList = value);
                  },
                ),
              ));
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () async {
          await showDialog(
            context: context,
            builder: (context) {
              return ShoppingListDialog(_dbHelper).buildDialog(
                  context, ShoppingList(tmp.savedId + 1, "", 0), true);
            },
          );
          _dbHelper
              .getMyShoppingList()
              .then((value) => tmp.setShoppingList = value);
        },
      ),
    );
  }

  @override
  void dispose() {
    _dbHelper.closeDB();
    super.dispose();
  }
}

class ScreenHistoryPertemuan3 extends StatefulWidget {
  const ScreenHistoryPertemuan3({Key? key}) : super(key: key);

  @override
  State<ScreenHistoryPertemuan3> createState() =>
      _ScreenHistoryPertemuan3State();
}

class _ScreenHistoryPertemuan3State extends State<ScreenHistoryPertemuan3> {
  DBHelper _dbHelper = DBHelper();

  @override
  Widget build(BuildContext context) {
    var tmp = Provider.of<ListProductProvider>(context, listen: true);
    _dbHelper.getMyHistoryList().then((value) => tmp.sethistoryList = value);

    return Scaffold(
      appBar: AppBar(
        title: const Text('History Changes'),
      ),
      body: ListView.builder(
        itemCount: tmp.historyList != [] ? tmp.historyList.length : 0,
        itemBuilder: (context, index) {
          return Stack(children: [
            Positioned(
              top: 5,
              right: 0,
              child: Text(
                tmp.historyList[index].date.toString(),
                style: const TextStyle(fontSize: 11, color: Colors.grey),
              ),
            ),
            Container(
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: Colors.grey, width: 0.5),
                ),
              ),
              child: ListTile(
                leading: (tmp.historyList[index].type == "INSERT")
                    ? const Icon(
                        Icons.edit,
                        color: Colors.green,
                      )
                    : (tmp.historyList[index].type == "UPDATE")
                        ? const Icon(
                            Icons.update_rounded,
                            color: Colors.greenAccent,
                          )
                        : (tmp.historyList[index].type == "DELETE")
                            ? const Icon(
                                Icons.delete,
                                color: Colors.redAccent,
                              )
                            : const Icon(
                                Icons.delete_forever,
                                color: Colors.red,
                              ),
                title: Text(tmp.historyList[index].type),
                subtitle: Text(tmp.historyList[index].comment),
              ),
            ),
          ]);
        },
      ),
    );
  }
}

class ItemScreen extends StatefulWidget {
  final ShoppingList shoppingList;
  const ItemScreen(this.shoppingList);

  @override
  _ItemScreenState createState() => _ItemScreenState(this.shoppingList);
}

class _ItemScreenState extends State<ItemScreen> {
  final ShoppingList shoppingList;
  _ItemScreenState(this.shoppingList);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(shoppingList.name),
      ),
    );
  }
}

class ShoppingListDialog {
  DBHelper _dbHelper;
  ShoppingListDialog(this._dbHelper);

  final txtName = TextEditingController();
  final txtSum = TextEditingController();

  Widget buildDialog(BuildContext context, ShoppingList list, bool isNew) {
    if (!isNew) {
      txtName.text = list.name;
      txtSum.text = list.sum.toString();
    } else {
      txtName.text = "";
      txtSum.text = "";
    }
    return AlertDialog(
      title: Text((isNew) ? 'New shopping list' : 'Edit shopping list'),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
      content: SingleChildScrollView(
        child: Column(
          children: [
            TextField(
              controller: txtName,
              decoration: const InputDecoration(hintText: 'Shopping List Name'),
            ),
            TextField(
              controller: txtSum,
              decoration: const InputDecoration(hintText: 'Sum'),
            ),
            ElevatedButton(
              onPressed: () {
                list.name = txtName.text != "" ? txtName.text : "Empty";
                list.sum = txtSum.text != "" ? int.parse(txtSum.text) : 0;
                _dbHelper.insertShoppingList(list, isNew);
                Navigator.pop(context);
              },
              child: const Text('Save Shopping List'),
            )
          ],
        ),
      ),
    );
  }
}
